jQuery(document).ready(function ($) {
	
	var key = [9, 13, 19, 20, 27, 33, 34, 35, 36, 37, 38, 39, 40, 91, 92, 93]; //Tab Enter Pause CapsLock Esc PageUp PageDown End Home стрелка влево стрелка вверх cтрелка вправо стрелка вниз левая Windows правая Windows Applications
	
	//through all inputs
	$('.radiofan-search').each(function (ind, el){
		$(el).children('input').on({
			
			//show select list
			focus: function(e){
				$(this).siblings('.radiofan-select').slideDown({
				  duration: 200,
				  easing: "linear",
				  queue: true
				});
			},
			
			//hide select list
			blur: function(e){
				$(this).siblings('.radiofan-select').slideUp({
				  duration: 100,
				  easing: "linear",
				  queue: true
				});
			},
			
			//input change for this reason through options and compare with input value
			keyup: function(e){
				if(key.indexOf(e.which) != -1 || (e.which >= 112 && e.which <= 157)) return;
				var val = $(this).val().trim();
				if(val == ''){
					$(el).find('.radiofan-option').each(function (index, elem){
						$(elem).show();
					});
				}else{
					var reg = new RegExp('^'+val, 'ig');
					var reg1 = new RegExp('^'+val+'$', 'ig');
					$(el).find('.radiofan-option').each(function (index, elem){
						var eltxt = $(elem).text();
						if(reg.test(eltxt) || $(elem).hasClass('default-region')){
							$(elem).show();
						}else{
							$(elem).hide();
						}
						
						//if complete coincidence then fill input this coincidence
						if(reg1.test(eltxt)){
							$(el).children('input').val(eltxt);
						}
					});
				}
			}
		});
		
		//if click on option then fill input this option
		$(el).find('.radiofan-option').each(function (index, elem){
			$(elem).mousedown(function(e){
				var txt = $(elem).text();
				$(el).children('input').val(txt);
			});
		});
	});
});





/*
var radList = [];//массив со списками выбора

jQuery(document).ready(function ($) {
	
	var hide = {duration: 100, easing: "linear", queue: true};
	
	//var i = -1;//индекс массива(количество калькуляторов)
	
	$('.radiofan-search').each(function (ind, el){
		$(el).children('input').focus(function(){
			$('.radiofan-search').not(el).each(function(index, elem){
				$(elem).children('.radiofan-select').slideUp(hide);
			});
			$(this).siblings('.radiofan-select').slideDown({
			  duration: 200,
			  easing: "linear",
			  queue: true
			});
		});
		
		radList.push(0);
		//i += 1;
		
		$(el).find('.radiofan-option').each(function (index, elem){
			radList[ind] += 1;
			$(elem).click(function(){
				var txt = $(elem).text();
				$(el).children('input').val(txt);
				$(el).children('.radiofan-select').slideUp(hide);
			});
		});
		
		$(el).keydown(function(e){
			if($(el).children('input:focus')){
				console.log(e.which);
				if(e.which == 9){//tab
					$(el).children('.radiofan-select').slideUp(hide);
				}
			}
		});
		
		$(el).keyup(function(e){
			if($(el).children('input:focus')){
				console.log(e.which);
				if(e.which == 18){//alt
					$(el).children('.radiofan-select').slideUp(hide);
				}else if(e.which == 40){//стрелка вниз
					
				}
			}
		});
		
		$(document).click(function(e) {
			if ($(e.target).closest('.radiofan-search').length) return;
			$(e.target).find('.radiofan-select').each(function(index, elem){
				$(elem).slideUp(hide);
			});
			e.stopPropagation();
		});
	});
});

jQuery(document).ready(function ($) {
	
	var hide = {duration: 100, easing: "linear", queue: true};
	
	$('.radiofan-search').each(function (ind, el){
		$(el).children('input').focus(function(e){
			$(this).siblings('.radiofan-select').slideDown({
			  duration: 200,
			  easing: "linear",
			  queue: true
			});
		});
		
		$(el).children('input').blur(function(e){
			$(this).siblings('.radiofan-select').slideUp(hide);
		});
		
		$(el).find('.radiofan-option').each(function (index, elem){
			$(elem).mousedown(function(e){
				var txt = $(elem).text();
				$(el).children('input').val(txt);
			});
		});
	});
});
*/
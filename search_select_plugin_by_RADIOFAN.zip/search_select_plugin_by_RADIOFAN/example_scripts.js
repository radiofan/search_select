jQuery(document).ready(function ($) {
	
	var key = [9, 13, 19, 20, 27, 33, 34, 35, 36, 37, 38, 39, 40, 91, 92, 93]; //Tab Enter Pause CapsLock Esc PageUp PageDown End Home стрелка влево стрелка вверх cтрелка вправо стрелка вниз левая Windows правая Windows Applications
	
	//through all inputs
	//Перебор всех инпутов
	$('.radiofan-search').each(function (ind, el){
		$(el).children('input').on({
			
			//show options list and return user value
			//Показываем список и вставляем введенное пользователем значение
			focus: function(e){
				if($(this).data('value') != $(this).val()){
					$(this).val($(this).data('value')).data('value', '');
				}
				$(this).siblings('.radiofan-select').slideDown({
				  duration: 200,
				  easing: "linear",
				  queue: true
				});
			},
			
			//hide options list and replace non validated user value
			//Скрываем список и заменяем не валидное значение пользователя на первую опцию по умолчанию
			blur: function(e){
				if($(this).data('value') != $(this).val()){
					$(this).data('value', $(this).val());
					$(this).val($(el).find('.radiofan-option.default-region:first').text());
				}
				$(this).siblings('.radiofan-select').slideUp({
				  duration: 100,
				  easing: "linear",
				  queue: true
				});
			},
			
			//input change for this reason through options and compare with input value
			//Смена текста в инпуте запускает проверку значения с опциями и скрывает не подходящие
			keyup: function(e){
				if(key.indexOf(e.which) != -1 || (e.which >= 112 && e.which <= 157)) return;
				var val = $(this).val().trim();
				if(val == ''){
					$(el).find('.radiofan-option').each(function (index, elem){
						$(elem).show();
					});
				}else{
					var reg = new RegExp('^'+val, 'ig');
					var reg1 = new RegExp('^'+val+'$', 'ig');
					$(el).find('.radiofan-option').each(function (index, elem){
						var eltxt = $(elem).text();
						if(reg.test(eltxt) || $(elem).hasClass('default-region')){
							$(elem).show();
						}else{
							$(elem).hide();
						}
						
						//if complete coincidence then fill input this coincidence
						//Если полное совпадение то заполнить значением опции инпут
						if(reg1.test(eltxt)){
							$(el).children('input').data('value', eltxt).val(eltxt);
						}
					});
				}
			}
		});
		
		//choice options with the arrow keys and enter
		//Выбор опций с помощью стрелок и ввода
		var $opt;
		var scrol = 0;
		$(el).keydown(function(e){
			if($(el).children('.radiofan-select').is(':visible')){
				switch(e.which){
					case 38://↑
						e.preventDefault();
						$opt = $(el).find('.radiofan-option.select-region');
						if($($opt).size()){
							$($opt).removeClass('select-region');
							if($($opt).prevAll('.radiofan-option:visible:first').addClass('select-region').size() == 0){
								scrol = 0;
							}
						}else if(scrol == 1){
							$(el).find('.radiofan-option:last').addClass('select-region');
							scrol = 2;
						}
						break;
					case 40://↓
						e.preventDefault();
						$opt = $(el).find('.radiofan-option.select-region');
						if($($opt).size()){
							$($opt).removeClass('select-region');
							if($($opt).nextAll('.radiofan-option:visible:first').addClass('select-region').size() == 0){
								scrol = 1;
							}
						}else if(scrol == 0){
							$(el).find('.radiofan-option:visible:first').addClass('select-region');
							scrol = 2;
						}
						break;
					case 13://enter
						e.preventDefault();
						$opt = $(el).find('.radiofan-option.select-region');
						if($($opt).size()){
							$($opt).removeClass('select-region');
							scrol = 0;
							$(el).children('input').data('value', $($opt).text())
							.val($($opt).text())
							.blur();
						}
						break;
					default:
						break;
				}
			}
		});
		
		//click on option fill input this option's value
		//Клик по опции заполняет инпут значением выбранной опции
		$(el).find('.radiofan-option').each(function (index, elem){
			$(elem).mousedown(function(e){
				var txt = $(elem).text();
				$(el).children('input').val(txt).data('value', txt);
			});
		});
	});
});